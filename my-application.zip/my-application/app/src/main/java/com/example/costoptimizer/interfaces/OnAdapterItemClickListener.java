package com.example.costoptimizer.interfaces;

public interface OnAdapterItemClickListener<T> {
    void onAdapterItemClick(T item);

    default Boolean onAdapterItemLongClick(T item){
        return false;
    }
}
